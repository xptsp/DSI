#include <windows.h>

/**
 * This blank entry should be used only if we are building a DLL (obviously!)
 * and if we are NOT statically linking the CRT (if we are, then we need to use
 * the default CRT entry point so that the heap is initialized).
 **/

#if defined(_USRDLL) && defined(_DLL)

#pragma comment(linker, "/entry:DllMain")
BOOL WINAPI DllMain( HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved )
{
	if (dwReason == DLL_PROCESS_ATTACH)
		DisableThreadLibraryCalls(hInstance);

	return(TRUE);
}

#endif
