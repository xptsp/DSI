#ifndef __CABLITE_H__
#define __CABLITE_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <windows.h>

typedef PVOID HCABLITE, *PHCABLITE;

/**
 * CabFile and CabDirectory return a DWORD (UINT32) code
 *
 * The low word holds status information, and the high word holds the number
 * of files successfully added.
 *
 * Bit     00: 1=success, 0=error
 * Bit     01: 1=dir_count_mismatch, 0=normal
 * Bits 02-05: extended status (4-bit unsigned nybble)
 * Bits 06-15: reserved
 * Bits 16-31: number of files added
 *
 * dir_count_mismatch bit: This bit (b1) is set if CabDirectory was called and
 *                         the number of added files does not match the number
 *                         that was expected; this could be the result of
 *                         unreadable files or of external changes to the
 *                         directory during the cabbing operation.
 *
 * Extended status codes if b0=1 (success):
 * 0: normal return
 *
 * Extended status codes if b0=0 (error):
 * 0: initialization error
 * 1: cab creation error
 * 2: cleanup error
 *
 * Remember that the extended status codes should be shifted by two bits!
 **/

#define CABLITE_MASK_STATUS     0x00000001
#define CABLITE_SUCCESS         0x00000001
#define CABLITE_ERROR           0x00000000

#define CABLITE_MISMATCH        0x00000002

#define CABLITE_MASK_EXTSTATUS  0x0000003C
#define CABLITE_SUCCESS_NORMAL  0x00000000
#define CABLITE_ERROR_INIT      0x00000000
#define CABLITE_ERROR_CAB       0x00000004
#define CABLITE_ERROR_CLEANUP   0x00000008

/**
 * Callbacks
 *
 * Note that the extraction status callback definitions should be compatible
 * with those in the private CabBase header.
 **/

typedef void (CALLBACK *PFNCABDIRECTORYSTATUSCALLBACK)(
	LPCSTR lpszCurrentFile,      // zero-length when flushing final cabinet to disk
	WORD wCompletedFiles,
	WORD wTotalFiles
);

typedef void (CALLBACK *PFNCABEXTRACTSTATUSCALLBACK)(
	LPCSTR lpszCurrentFile,
	WORD wExtractedFiles,
	WORD wAction                 // see codes below
);

#define CABLITE_EXTRACTION_ACTION_SKIPPING  0  // cannot create/open output file
#define CABLITE_EXTRACTION_ACTION_STARTING  1  // starting extraction
#define CABLITE_EXTRACTION_ACTION_FINISHED  2  // file extracted and written

typedef void (CALLBACK *PFNCABTHREADFINISHCALLBACK)(
	DWORD dwResult,              // same as the non-async function's return
	LPCSTR lpszInput             // input string (source file/dir/cabinet)
);

/**
 * Standard Operation: Compression
 **/

DWORD WINAPI CabFile(            // RETURN: 32-bit return code (see documentation)
	LPCSTR lpszFileName,         // path to source file
	LPCSTR lpszCabName           // [optional] path to output cabinet
);

HANDLE WINAPI CabFileAsync(      // RETURN: thread handle; call CloseHandle when done
	LPCSTR lpszFileName,         // path to source file
	LPCSTR lpszCabName,          // [optional] path to output cabinet
	PFNCABTHREADFINISHCALLBACK pfnCabThreadFinishCallback        // [optional]
);

DWORD WINAPI CabDirectory(       // RETURN: 32-bit return code (see documentation)
	LPCSTR lpszDirectoryName,    // path to source directory
	LPCSTR lpszCabName,          // [optional] path to output cabinet
	PFNCABDIRECTORYSTATUSCALLBACK pfnCabDirectoryStatusCallback  // [optional]
);

HANDLE WINAPI CabDirectoryAsync( // RETURN: thread handle; call CloseHandle when done
	LPCSTR lpszDirectoryName,    // path to source directory
	LPCSTR lpszCabName,          // [optional] path to output cabinet
	PFNCABDIRECTORYSTATUSCALLBACK pfnCabDirectoryStatusCallback, // [optional]
	PFNCABTHREADFINISHCALLBACK pfnCabThreadFinishCallback        // [optional]
);

/**
 * Standard Operation: Decompression/Extraction
 **/

WORD WINAPI CabExtract(          // RETURN: number of files extracted
	LPCSTR lpszCabName,          // path to the cabinet to decompress
	LPCSTR lpszOutputPath,       // [optional] path to place extracted files
	PFNCABEXTRACTSTATUSCALLBACK pfnCabExtractStatusCallback      // [optional]
);

HANDLE WINAPI CabExtractAsync(   // RETURN: thread handle; call CloseHandle when done
	LPCSTR lpszCabName,          // path to the cabinet to decompress
	LPCSTR lpszOutputPath,       // [optional] path to place extracted files
	PFNCABEXTRACTSTATUSCALLBACK pfnCabExtractStatusCallback,     // [optional]
	PFNCABTHREADFINISHCALLBACK pfnCabThreadFinishCallback        // [optional]
);

/**
 * Advanced/Manual Operation: Compression
 **/

HCABLITE WINAPI CabStart(        // RETURN: handle for CabAdd/CabFinish; NULL=fail
	LPCSTR lpszCabName,          // path to the cabinet to create
	USHORT uSolidBlockSizeInMB   // [optional] solid block size, in MB
);

WORD WINAPI CabAdd(              // RETURN: number of files added
	HCABLITE hCabLite,           // handle obtained from CabStart
	LPCSTR lpszSourceName,       // path to source file/directory
	LPCSTR lpszDestName          // [optional] name to store in the cabinet
);

WORD WINAPI CabAddStepInit(      // RETURN: number of files for CabAddStep
	HCABLITE hCabLite,           // handle obtained from CabStart
	LPCSTR lpszDirectoryName,    // path to source directory
	LPCSTR lpszDestName          // [optional] name to store in the cabinet
);

WORD WINAPI CabAddStep(          // RETURN: number of files added
	HCABLITE hCabLite,           // handle obtained from CabStart
	WORD wIndex                  // index to add; get max index from CabAddStepInit
);

BOOL WINAPI CabFinish(           // RETURN: was the cabinet successfully created?
	HCABLITE hCabLite            // handle obtained from CabStart
);

#ifdef __cplusplus
}
#endif

#endif
