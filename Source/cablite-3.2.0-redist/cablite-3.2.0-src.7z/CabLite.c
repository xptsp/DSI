#include <windows.h>
#include "CabLite.h"
#include "CabBase.h"
#include "ReadDirectoryTree.h"
#include "StringIntrinsics.h"
#include "version.h"

/**
 * Information that needs to persist in manual cabbing mode
 **/

typedef struct {
	// General session information
	HFCI hfci;
	ERF erf;
	CCAB ccab;

	// Information needed for CabAddStep
	WORD wFiles;
	CHAR szSource[MAX_PATH];
	CHAR szDest[MAX_PATH];
	LPSTR lpszSourceAppend;
	LPSTR lpszDestAppend;
	PWORD pwIndexes;
	LPSTR lpszSubPaths;
} CABINFO, *PCABINFO;

/**
 * Arguments for threaded functions, packaged as a struct
 **/

typedef struct {
	CHAR szArg1[MAX_PATH];
	CHAR szArg2[MAX_PATH];
	PVOID pvArg3;
	PFNCABTHREADFINISHCALLBACK pfnCabThreadFinishCallback;
} THREADARGS, *PTHREADARGS;

/**
 * List of different ways to generate an automatic cabinet name.
 **/

typedef enum {
	ACN_NONE,       // Do nothing; use the supplied name as-is
	ACN_UNDERSCORE, // Use a trailing underscore
	ACN_CABEXT      // Append the ".cab" extension
} AUTOCABNAME, *PAUTOCABNAME;

/**
 * InitCCab - Initializes cabinet struct and splits cabinet path name
 **/

BOOL InitCCab( PCCAB pccab, LPCSTR lpszCabName, AUTOCABNAME acn )
{
	LPCSTR lpszTail;

	if (!lpszCabName)
		return(FALSE);

	// Initialize the structure...
	memset(pccab, 0, sizeof(CCAB));
	pccab->cb = MAX_CAB_SIZE;
	pccab->cbFolderThresh = MAX_CAB_SIZE;

	if (lpszTail = strrchr(lpszCabName, '\\'))
	{
		SIZE_T cbPath = (++lpszTail) - lpszCabName;

		if (cbPath >= CB_MAX_CAB_PATH)
			return(FALSE);

		// When the string length is known, memcpy is faster; memset gave us
		// our terminating null...
		memcpy(pccab->szCabPath, lpszCabName, cbPath);
	}
	else
	{
		lpszTail = lpszCabName;

		// Default to ".\"; memset gave us our terminating null...
		strcpy2chA(pccab->szCabPath, '.', '\\');
	}

	if (!(*lpszTail && strlen(lpszTail) < CB_MAX_CABINET_NAME - 4))
		return(FALSE);

	strcpy(pccab->szCab, lpszTail);

	if (IsSpecialDirectoryName(pccab->szCab))
		return(FALSE);

	// Generate an automatic "cabified" file name?
	if (acn == ACN_UNDERSCORE)
	{
		LPSTR lpszCabExt = strrchr(pccab->szCab, '.');

		if (lpszCabExt)
		{
			// If the extension is 3 or more characters long, change the third
			// character to an underscore and truncate the rest, otherwise,
			// just append an underscore...

			SIZE_T cbCabExt = strlen(lpszCabExt);

			if (cbCabExt > 3)
				strcpy2chA(lpszCabExt + 3, '_', 0);
			else
				strcpy2chA(lpszCabExt + cbCabExt, '_', 0);
		}
		else
		{
			// No extension at all...
			strcat(pccab->szCab, "._");
		}
	}
	else if (acn == ACN_CABEXT)
	{
		strcat(pccab->szCab, ".cab");
	}

	return(TRUE);
}

/**
 * Wrapper for FCICreate
 **/

HFCI CreateCab( LPCSTR lpszCabName, ULONG cbSolidBlockSize,
                AUTOCABNAME acn, PERF perf, PCCAB pccab )
{
	if (!InitCCab(pccab, lpszCabName, acn))
		return(NULL);

	if (cbSolidBlockSize && cbSolidBlockSize < pccab->cbFolderThresh)
		pccab->cbFolderThresh = cbSolidBlockSize;

	CreateDirectoryTreeA(pccab->szCabPath);

	return(FCICreate(
		perf,
		fciFilePlaced,
		fnmalloc,
		fnfree,
		fciopen,
		fciread,
		fciwrite,
		fciclose,
		fciseek,
		fcidelete,
		fciGetTempFile,
		pccab,
		NULL
	));
}

/**
 * Wrapper for FCIAddFile
 **/

BOOL AddToCab( HFCI hfci, LPCSTR lpszSourceFile, LPCSTR lpszStoredName )
{
	if (!(lpszStoredName && *lpszStoredName))
	{
		lpszStoredName = strrchr(lpszSourceFile, '\\');

		if (!(lpszStoredName && *(++lpszStoredName)))
			lpszStoredName = lpszSourceFile;
	}

	return(FCIAddFile(hfci, (LPSTR)lpszSourceFile, (LPSTR)lpszStoredName, FALSE,
	                  fciGetNextCabinet, fciStatus, fciGetOpenInfo,
	                  tcompTYPE_LZX | tcompLZX_WINDOW_HI));
}

/**
 * I am too cheap to use shlwapi.lib for this...
 **/

BOOL CopyAndStripSlash( LPCSTR lpszSource, LPSTR lpszDest, SIZE_T cbDest )
{
	SIZE_T cbSource;

	if (!(lpszSource && *lpszSource && (cbSource = strlen(lpszSource)) < cbDest))
		return(FALSE);

	// If we already know the length, memcpy is faster
	memcpy(lpszDest, lpszSource, cbSource + 1);

	if (lpszDest[cbSource - 1] == '\\')
		lpszDest[cbSource - 1] = 0;

	return(TRUE);
}

/**
 * InitThreadArgs - Prepares data for use by a thread
 **/

PTHREADARGS InitThreadArgs( LPCSTR pszArg1, LPCSTR pszArg2, PVOID pvArg3,
                            PFNCABTHREADFINISHCALLBACK pfnCabThreadFinishCallback )
{
	PTHREADARGS pThreadArgs = malloc(sizeof(THREADARGS));
	memset(pThreadArgs, 0, sizeof(THREADARGS));

	if (pszArg1) strcpy(pThreadArgs->szArg1, pszArg1);
	if (pszArg2) strcpy(pThreadArgs->szArg2, pszArg2);
	pThreadArgs->pvArg3 = pvArg3;
	pThreadArgs->pfnCabThreadFinishCallback = pfnCabThreadFinishCallback;

	return(pThreadArgs);
}

/**
 * Exported function:
 * CabFile()
 **/

DWORD WINAPI CabFile( LPCSTR lpszFileName,
                      LPCSTR lpszCabName )
{
	HFCI     hfci;
	ERF      erf;
	CCAB     ccab;
	FILETIME filetime;

	if (!(lpszFileName && *lpszFileName))
		return(CABLITE_ERROR_INIT);

	hfci = (lpszCabName && *lpszCabName) ?
		CreateCab(lpszCabName, 0, ACN_NONE, &erf, &ccab) :
		CreateCab(lpszFileName, 0, ACN_UNDERSCORE, &erf, &ccab);

	if (!hfci)
		return(CABLITE_ERROR_INIT);

	if (!AddToCab(hfci, lpszFileName, NULL) ||
	    !FCIFlushCabinet(hfci, FALSE, fciGetNextCabinet, fciStatus))
	{
		FCIDestroy(hfci);
		return(CABLITE_ERROR_CAB);
	}

	if (!FCIDestroy(hfci))
		return(CABLITE_ERROR_CLEANUP | 1 << 16);

	if (GetFileTimeByNameA(lpszFileName, &filetime))
	{
		CHAR szFinalCabPath[MAX_PATH];
		strcpycatA(szFinalCabPath, ccab.szCabPath, ccab.szCab);
		SetFileTimeByNameA(szFinalCabPath, &filetime);
	}

	return(CABLITE_SUCCESS | 1 << 16);
}

/**
 * Exported function:
 * CabFileAsync()
 **/

DWORD WINAPI CabFileThread( PTHREADARGS pThreadArgs )
{
	DWORD dwResult = CabFile(pThreadArgs->szArg1, pThreadArgs->szArg2);

	if (pThreadArgs->pfnCabThreadFinishCallback)
		pThreadArgs->pfnCabThreadFinishCallback(dwResult, pThreadArgs->szArg1);

	free(pThreadArgs);
	return(dwResult);
}

HANDLE WINAPI CabFileAsync( LPCSTR lpszFileName,
                            LPCSTR lpszCabName,
                            PFNCABTHREADFINISHCALLBACK pfnCabThreadFinishCallback )
{
	PTHREADARGS pThreadArgs = InitThreadArgs(
		lpszFileName,
		lpszCabName,
		NULL,
		pfnCabThreadFinishCallback
	);

	return((HANDLE)_beginthreadex(NULL, 0, CabFileThread, pThreadArgs, 0, NULL));
}

/**
 * Exported function:
 * CabDirectory()
 **/

DWORD WINAPI CabDirectory( LPCSTR lpszDirectoryName,
                           LPCSTR lpszCabName,
                           PFNCABDIRECTORYSTATUSCALLBACK pfnCabDirectoryStatusCallback )
{
	HFCI  hfci;
	ERF   erf;
	CCAB  ccab;
	CHAR  szDirectoryPath[MAX_PATH];
	WORD  wTotalFiles;
	PWORD pwIndexes;
	LPSTR lpszSubPaths;
	DWORD dwRet = CABLITE_ERROR_INIT;

	if (!CopyAndStripSlash(lpszDirectoryName, szDirectoryPath, sizeof(szDirectoryPath)))
		return(CABLITE_ERROR_INIT);

	ReadDirectoryTree(szDirectoryPath, &wTotalFiles, &pwIndexes, &lpszSubPaths);

	if (!wTotalFiles)
		return(CABLITE_ERROR_INIT);

	hfci = (lpszCabName && *lpszCabName) ?
		CreateCab(lpszCabName, 8 << 20, ACN_NONE, &erf, &ccab) :
		CreateCab(szDirectoryPath, 8 << 20, ACN_CABEXT, &erf, &ccab);

	if (hfci)
	{
		WORD wCurrentFile;
		WORD wAddedFiles = 0;
		LPSTR lpszSubPath;
		LPSTR lpszPath = szDirectoryPath;
		LPSTR lpszPathAppend = lpszPath + strlen(lpszPath);

		strcpy2chA(lpszPathAppend++, '\\', 0);

		for (wCurrentFile = 0; wCurrentFile < wTotalFiles; ++wCurrentFile)
		{
			lpszSubPath = lpszSubPaths + pwIndexes[wCurrentFile] * RDT_STRLEN;
			strcpy(lpszPathAppend, lpszSubPath);

			if (pfnCabDirectoryStatusCallback)
				pfnCabDirectoryStatusCallback(lpszSubPath, wCurrentFile, wTotalFiles);

			if (AddToCab(hfci, lpszPath, lpszSubPath))
				++wAddedFiles;
		}

		// Send notification that we are now finalizing the cabinet
		if (pfnCabDirectoryStatusCallback)
			pfnCabDirectoryStatusCallback("", wCurrentFile, wTotalFiles);

		dwRet = wAddedFiles << 16;

		if (wAddedFiles != wTotalFiles)
			dwRet |= CABLITE_MISMATCH;

		if (!wAddedFiles || !FCIFlushCabinet(hfci, FALSE, fciGetNextCabinet, fciStatus))
		{
			FCIDestroy(hfci);
			dwRet |= CABLITE_ERROR_CAB;
		}
		else if (!FCIDestroy(hfci))
			dwRet |= CABLITE_ERROR_CLEANUP;
		else
			dwRet |= CABLITE_SUCCESS;
	}

	free(pwIndexes);
	free(lpszSubPaths);
	return(dwRet);
}

/**
 * Exported function:
 * CabDirectoryAsync()
 **/

DWORD WINAPI CabDirectoryThread( PTHREADARGS pThreadArgs )
{
	DWORD dwResult = CabDirectory(pThreadArgs->szArg1, pThreadArgs->szArg2, pThreadArgs->pvArg3);

	if (pThreadArgs->pfnCabThreadFinishCallback)
		pThreadArgs->pfnCabThreadFinishCallback(dwResult, pThreadArgs->szArg1);

	free(pThreadArgs);
	return(dwResult);
}

HANDLE WINAPI CabDirectoryAsync( LPCSTR lpszDirectoryName,
                                 LPCSTR lpszCabName,
                                 PFNCABDIRECTORYSTATUSCALLBACK pfnCabDirectoryStatusCallback,
                                 PFNCABTHREADFINISHCALLBACK pfnCabThreadFinishCallback )
{
	PTHREADARGS pThreadArgs = InitThreadArgs(
		lpszDirectoryName,
		lpszCabName,
		pfnCabDirectoryStatusCallback,
		pfnCabThreadFinishCallback
	);

	return((HANDLE)_beginthreadex(NULL, 0, CabDirectoryThread, pThreadArgs, 0, NULL));
}

/**
 * Exported function:
 * CabExtract()
 **/

WORD WINAPI CabExtract( LPCSTR lpszCabName,
                        LPCSTR lpszOutputPath,
                        PFNCABEXTRACTSTATUSCALLBACK pfnCabExtractStatusCallback )
{
	HFDI        hfdi;
	ERF         erf;
	CCAB        ccab;
	EXTRACTDATA ed;

	if (!InitCCab(&ccab, lpszCabName, ACN_NONE))
		return(0);

	if (lpszOutputPath && *lpszOutputPath)
	{
		if (!CopyAndStripSlash(lpszOutputPath, ed.szOutputPath, sizeof(ed.szOutputPath)))
			return(0);
	}
	else
	{
		SIZE_T cbCabPath = strlen(ccab.szCabPath);
		LPSTR lpszCabTail, lpszCabExt;

		// ccab.szCabPath is guaranteed to be terminated by a slash
		memcpy(ed.szOutputPath, ccab.szCabPath, cbCabPath);
		lpszCabTail = ed.szOutputPath + cbCabPath;

		// Append file name and then point the tail at the final slash
		strcpy(lpszCabTail--, ccab.szCab);

		// Find the file extension; it is important that we limit this search
		// to only the tail: we do not want dots before the final slash!
		lpszCabExt = strrchr(lpszCabTail, '.');

		if (!lpszCabExt || *(lpszCabExt + 1) == 0 || *(lpszCabExt - 1) == '\\' ||
		    lpszCabExt[strlen(lpszCabExt) - 1] == '_')
		{
			// If the cabinet has no extension (dot not found or is the final
			// character, if the file only has an extension (e.g., a file named
			// ".cab"), or if the extension ends in an underscore, we should
			// extract to the cabinet's path...
			*lpszCabTail = 0;
		}
		else
		{
			// ...otherwise, extract to a directory named after the cabinet...
			*lpszCabExt = 0;
		}
	}

	hfdi = FDICreate(
		fnmalloc,
		fnfree,
		fdiopen,
		fdiread,
		fdiwrite,
		fdiclose,
		fdiseek,
		cpuUNKNOWN,
		&erf
	);

	if (!hfdi) return(0);

	strcat(ed.szOutputPath, "\\");
	ed.wExtractedFiles = 0;
	ed.pfnExtractionStatus = pfnCabExtractStatusCallback;

	FDICopy(hfdi, ccab.szCab, ccab.szCabPath, 0, fdiNotify, NULL, &ed);
	FDIDestroy(hfdi);

	return(ed.wExtractedFiles);
}

/**
 * Exported function:
 * CabExtractAsync()
 **/

DWORD WINAPI CabExtractThread( PTHREADARGS pThreadArgs )
{
	DWORD dwResult = CabExtract(pThreadArgs->szArg1, pThreadArgs->szArg2, pThreadArgs->pvArg3);

	if (pThreadArgs->pfnCabThreadFinishCallback)
		pThreadArgs->pfnCabThreadFinishCallback(dwResult, pThreadArgs->szArg1);

	free(pThreadArgs);
	return(dwResult);
}

HANDLE WINAPI CabExtractAsync( LPCSTR lpszCabName,
                               LPCSTR lpszOutputPath,
                               PFNCABEXTRACTSTATUSCALLBACK pfnCabExtractStatusCallback,
                               PFNCABTHREADFINISHCALLBACK pfnCabThreadFinishCallback )
{
	PTHREADARGS pThreadArgs = InitThreadArgs(
		lpszCabName,
		lpszOutputPath,
		pfnCabExtractStatusCallback,
		pfnCabThreadFinishCallback
	);

	return((HANDLE)_beginthreadex(NULL, 0, CabExtractThread, pThreadArgs, 0, NULL));
}

/**
 * Exported function:
 * CabStart()
 **/

HCABLITE WINAPI CabStart( LPCSTR lpszCabName,
                          USHORT uSolidBlockSizeInMB )
{
	ULONG cbSolidBlockSize = (uSolidBlockSizeInMB < 0x800) ?
		uSolidBlockSizeInMB << 20 : 0;

	PCABINFO pCabInfo = malloc(sizeof(CABINFO));
	memset(pCabInfo, 0, sizeof(CABINFO));
	pCabInfo->hfci = CreateCab(lpszCabName, cbSolidBlockSize, ACN_NONE,
	                           &pCabInfo->erf, &pCabInfo->ccab);

	if (!pCabInfo->hfci)
	{
		free(pCabInfo);
		pCabInfo = NULL;
	}

	return(pCabInfo);
}

/**
 * CabAddEx()
 * This is the base for the CabAdd* family of functions
 **/

WORD CabAddEx( HCABLITE hCabLite,
               LPCSTR lpszSourceName,
               LPCSTR lpszDestName,
               BOOL bIsStepInit )
{
	BOOL wAddedFiles = 0;
	PCABINFO pCabInfo = hCabLite;
	DWORD dwFileAttributes;

	if (!(pCabInfo && pCabInfo->hfci &&
	      CopyAndStripSlash(lpszSourceName, pCabInfo->szSource, sizeof(pCabInfo->szSource))))
	{
		return(0);
	}

	dwFileAttributes = GetFileAttributesA(pCabInfo->szSource);

	if (dwFileAttributes == INVALID_FILE_ATTRIBUTES ||
	    dwFileAttributes & FILE_ATTRIBUTE_OFFLINE)
	{
	}
	else if (dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
	{
		WORD wCurrentFile;
		LPSTR lpszSubPath;

		ReadDirectoryTree(pCabInfo->szSource, &pCabInfo->wFiles,
		                  &pCabInfo->pwIndexes, &pCabInfo->lpszSubPaths);

		// Prepare the source path prefix
		pCabInfo->lpszSourceAppend = pCabInfo->szSource + strlen(pCabInfo->szSource);
		strcpy2chA(pCabInfo->lpszSourceAppend++, '\\', 0);

		// Prepare the destination path prefix
		*(pCabInfo->szDest) = 0;
		pCabInfo->lpszDestAppend = pCabInfo->szDest;

		if (lpszDestName)
		{
			// Strip away leading slashes and spaces
			while (*lpszDestName == '\\' || *lpszDestName == ' ') ++lpszDestName;

			if (*lpszDestName)
			{
				strcpy(pCabInfo->szDest, lpszDestName);

				// Since the prefix has a non-zero length, we now need to make
				// sure that there is exactly one trailing slash.

				// Strip away existing trailing slashes and spaces
				pCabInfo->lpszDestAppend += strlen(pCabInfo->lpszDestAppend) - 1;
				while (*(pCabInfo->lpszDestAppend) == '\\' ||
				       *(pCabInfo->lpszDestAppend) == ' ')
				{
					--pCabInfo->lpszDestAppend;
				}

				// Add single trailing slash
				*(++pCabInfo->lpszDestAppend) = '\\';
				*(++pCabInfo->lpszDestAppend) = 0;
			}
		}

		if (bIsStepInit) return(pCabInfo->wFiles);

		// Add the directory tree
		for (wCurrentFile = 0; wCurrentFile < pCabInfo->wFiles; ++wCurrentFile)
		{
			lpszSubPath = pCabInfo->lpszSubPaths + pCabInfo->pwIndexes[wCurrentFile] * RDT_STRLEN;
			strcpy(pCabInfo->lpszSourceAppend, lpszSubPath);
			strcpy(pCabInfo->lpszDestAppend, lpszSubPath);

			if (AddToCab(pCabInfo->hfci, pCabInfo->szSource, pCabInfo->szDest))
				++wAddedFiles;
		}

		if (pCabInfo->wFiles)
		{
			pCabInfo->wFiles = 0;
			free(pCabInfo->pwIndexes);
			free(pCabInfo->lpszSubPaths);
		}
	}
	else
	{
		if (bIsStepInit) return(0);

		if (AddToCab(pCabInfo->hfci, pCabInfo->szSource, lpszDestName))
			++wAddedFiles;
	}

	return(wAddedFiles);
}

/**
 * Exported function:
 * CabAdd()
 **/

WORD WINAPI CabAdd( HCABLITE hCabLite,
                    LPCSTR lpszSourceName,
                    LPCSTR lpszDestName )
{
	return(CabAddEx(hCabLite, lpszSourceName, lpszDestName, FALSE));
}

/**
 * Exported function:
 * CabAddStepInit()
 **/

WORD WINAPI CabAddStepInit( HCABLITE hCabLite,
                            LPCSTR lpszDirectoryName,
                            LPCSTR lpszDestName )
{
	return(CabAddEx(hCabLite, lpszDirectoryName, lpszDestName, TRUE));
}

/**
 * Exported function:
 * CabAddStep()
 **/

WORD WINAPI CabAddStep( HCABLITE hCabLite,
                        WORD wIndex )
{
	PCABINFO pCabInfo = hCabLite;

	if (!pCabInfo || !pCabInfo->hfci || !pCabInfo->wFiles)
		return(0);

	if (wIndex < pCabInfo->wFiles)
	{
		LPSTR lpszSubPath = pCabInfo->lpszSubPaths + pCabInfo->pwIndexes[wIndex] * RDT_STRLEN;
		strcpy(pCabInfo->lpszSourceAppend, lpszSubPath);
		strcpy(pCabInfo->lpszDestAppend, lpszSubPath);

		if (AddToCab(pCabInfo->hfci, pCabInfo->szSource, pCabInfo->szDest))
			return(1);
	}
	else if (wIndex == pCabInfo->wFiles)
	{
		pCabInfo->wFiles = 0;
		free(pCabInfo->pwIndexes);
		free(pCabInfo->lpszSubPaths);
	}

	return(0);
}

/**
 * Exported function:
 * CabFinish()
 **/

BOOL WINAPI CabFinish( HCABLITE hCabLite )
{
	BOOL bSuccess;
	PCABINFO pCabInfo = hCabLite;

	if (!pCabInfo || !pCabInfo->hfci)
		return(FALSE);

	bSuccess = FCIFlushCabinet(pCabInfo->hfci, FALSE, fciGetNextCabinet, fciStatus);

	FCIDestroy(pCabInfo->hfci);
	free(pCabInfo);

	return(bSuccess);
}
