#ifndef __CABBASE_H__
#define __CABBASE_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <windows.h>
#include <fci.h>
#include <fdi.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <io.h>
#include <sys/stat.h>
#include <process.h>

#define MAX_CAB_SIZE 0x7FFFFFFF

/**
 * Extraction status callback definitions
 * This should be duplicated in the public headers!
 **/

typedef void (CALLBACK *PFNEXTRACTIONSTATUS)(
	LPCSTR lpszCurrentFile,
	WORD wExtractedFiles,
	WORD wAction
);

#define EXTRACTION_ACTION_SKIPPING 0
#define EXTRACTION_ACTION_STARTING 1
#define EXTRACTION_ACTION_FINISHED 2

/**
 * End of extraction callback definitions
 **/

typedef struct {
	CHAR szOutputPath[MAX_PATH];
	WORD wExtractedFiles;
	PFNEXTRACTIONSTATUS pfnExtractionStatus;
} EXTRACTDATA, *PEXTRACTDATA;

#ifdef _WIN64
FNALLOC(fnmalloc);
#else
#define fnmalloc ((PFNALLOC)malloc)
#endif
#define fnfree   free

FNFCIOPEN(fciopen);
FNFCIREAD(fciread);
FNFCIWRITE(fciwrite);
FNFCICLOSE(fciclose);
FNFCISEEK(fciseek);
FNFCIDELETE(fcidelete);

FNFCIGETNEXTCABINET(fciGetNextCabinet);
FNFCIFILEPLACED(fciFilePlaced);
FNFCIGETOPENINFO(fciGetOpenInfo);
FNFCISTATUS(fciStatus);
FNFCIGETTEMPFILE(fciGetTempFile);

#ifdef _WIN64
FNOPEN(fdiopen);
FNREAD(fdiread);
FNWRITE(fdiwrite);
FNCLOSE(fdiclose);
FNSEEK(fdiseek);
#else
#define fdiopen  _open
#define fdiread  _read
#define fdiwrite _write
#define fdiclose _close
#define fdiseek  _lseek
#endif

FNFDINOTIFY(fdiNotify);

BOOL GetFileTimeByNameA( LPCSTR lpszFileName, LPFILETIME lpFileTime );
BOOL SetFileTimeByNameA( LPCSTR lpszFileName, LPFILETIME lpFileTime );

void CreateDirectoryTreeA( LPSTR lpszPath );

#ifdef __cplusplus
}
#endif

#endif
