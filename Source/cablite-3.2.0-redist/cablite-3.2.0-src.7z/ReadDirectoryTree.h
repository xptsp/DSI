#ifndef __READDIRECTORYTREE_H__
#define __READDIRECTORYTREE_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <windows.h>
#include "StringIntrinsics.h"

#define RDT_STRLEN MAX_PATH

__inline BOOL IsSpecialDirectoryName( PCSTR pszPath )
{
	// TRUE if name is "." or ".."
	return(
		(*((PWORD)pszPath) == CHARS2WORD('.', 0)) ||
		(*((PWORD)pszPath) == CHARS2WORD('.', '.') && pszPath[2] == 0)
	);
}

void ReadDirectoryTree( PCSTR pszPath,
                        WORD *pwEntries,
                        PWORD *ppwIndexes,
                        PSTR *ppszSubPaths );

#ifdef __cplusplus
}
#endif

#endif
