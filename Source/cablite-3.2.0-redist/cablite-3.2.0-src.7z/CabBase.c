#include "CabBase.h"
#include "StringIntrinsics.h"

#define FILE_ATTRIBUTE_STANDARD ( FILE_ATTRIBUTE_READONLY | \
                                  FILE_ATTRIBUTE_HIDDEN   | \
                                  FILE_ATTRIBUTE_SYSTEM   | \
                                  FILE_ATTRIBUTE_ARCHIVE )

/**
 * Time conversions
 **/

#ifdef CAB_USE_UTC

#define FileTimeToDosTime FileTimeToDosDateTime
#define DosTimeToFileTime DosDateTimeToFileTime

#else

__inline void FileTimeToDosTime( CONST LPFILETIME lpFileTime,
                                 LPWORD lpFatDate, LPWORD lpFatTime )
{
	FILETIME ftTemp;
	FileTimeToLocalFileTime(lpFileTime, &ftTemp);
	FileTimeToDosDateTime(&ftTemp, lpFatDate, lpFatTime);
}

__inline void DosTimeToFileTime( WORD wFatDate, WORD wFatTime,
                                 LPFILETIME lpFileTime )
{
	FILETIME ftTemp;
	DosDateTimeToFileTime(wFatDate, wFatTime, &ftTemp);
	LocalFileTimeToFileTime(&ftTemp, lpFileTime);
}

#endif

/**
 * FCI/FDI: Memory
 * We directly use the CRT whenever possible (see CabBase.h).
 **/

#ifdef _WIN64

FNALLOC(fnmalloc)
{
	return(malloc(cb));
}

#endif

/**
 * FCI: I/O
 **/

FNFCIOPEN(fciopen)
{
	INT_PTR result = _open(pszFile, oflag, pmode);

	if (result == -1)
		*err = errno;

	return(result);
}

FNFCIREAD(fciread)
{
	UINT result = (UINT)_read((int)hf, memory, cb);

	if (result != cb)
		*err = errno;

	return(result);
}

FNFCIWRITE(fciwrite)
{
	UINT result = (UINT)_write((int)hf, memory, cb);

	if (result != cb)
		*err = errno;

	return(result);
}

FNFCICLOSE(fciclose)
{
	int result = _close((int)hf);

	if (result != 0)
		*err = errno;

	return(result);
}

FNFCISEEK(fciseek)
{
	long result = _lseek((int)hf, dist, seektype);

	if (result == -1)
		*err = errno;

	return(result);
}

FNFCIDELETE(fcidelete)
{
	int result = remove(pszFile);

	if (result != 0)
		*err = errno;

	return(result);
}

/**
 * FCI: Misc
 **/

FNFCIGETNEXTCABINET(fciGetNextCabinet)
{
	// For simplicity, we will be forcing the use of a single output file and
	// will not handle splitting cabinets.
	return(FALSE);
}

FNFCIFILEPLACED(fciFilePlaced)
{
	return(0);
}

FNFCIGETOPENINFO(fciGetOpenInfo)
{
	FILETIME filetime;
	DWORD dwFileAttributes;

	// Get the file time

	if (!GetFileTimeByNameA(pszName, &filetime))
		return(-1);

	FileTimeToDosTime(&filetime, pdate, ptime);

	// Get file attributes; we are only interested in the "standard" bits

	dwFileAttributes = GetFileAttributesA(pszName);

	*pattribs = (dwFileAttributes != INVALID_FILE_ATTRIBUTES) ?
		(USHORT)(dwFileAttributes & FILE_ATTRIBUTE_STANDARD) :
		0;

	// Return handle using _open

	return(_open(pszName, _O_RDONLY | _O_BINARY));
}

FNFCISTATUS(fciStatus)
{
	return(MAX_CAB_SIZE);
}

FNFCIGETTEMPFILE(fciGetTempFile)
{
	LPSTR pszBuffer = _tempnam("", "cab");

	if (pszBuffer && strlen(pszBuffer) < (UINT)cbTempName)
	{
		strcpy(pszTempName, pszBuffer);
		free(pszBuffer);
		return(TRUE);
	}

	if (pszBuffer)
		free(pszBuffer);

	return(FALSE);
}

/**
 * FDI: I/O
 * On Win32, we can directly use the CRT, but on Win64, there are some types
 * that are 64-bit in FDI but 32-bit in the CRT, thus requiring casting.
 **/

#ifdef _WIN64

FNOPEN(fdiopen)
{
	return(_open(pszFile, oflag, pmode));
}

FNREAD(fdiread)
{
	return(_read((int)hf, pv, cb));
}

FNWRITE(fdiwrite)
{
	return(_write((int)hf, pv, cb));
}

FNCLOSE(fdiclose)
{
	return(_close((int)hf));
}

FNSEEK(fdiseek)
{
	return(_lseek((int)hf, dist, seektype));
}

#endif

/**
 * FDI: Misc
 **/

FNFDINOTIFY(fdiNotify)
{
	PEXTRACTDATA pExtractData = pfdin->pv;

	switch (fdint)
	{
		/* We don't care about the following three cases, so they will just
		 * hit the default return(0) at the end of the function.
		case fdintCABINET_INFO:
		case fdintPARTIAL_FILE:
		case fdintENUMERATE:
		 */

		case fdintCOPY_FILE:
		{
			INT_PTR hFile;
			CHAR szDest[MAX_PATH];
			CHAR szDir[MAX_PATH];
			LPSTR lpszDirTail;

			strcpycatA(szDest, pExtractData->szOutputPath, pfdin->psz1);

			strcpy(szDir, szDest);
			lpszDirTail = strrchr(szDir, '\\');
			if (lpszDirTail) *lpszDirTail = 0;

			CreateDirectoryTreeA(szDir);

			hFile = fdiopen(
				szDest,
				_O_BINARY | _O_CREAT | _O_TRUNC | _O_WRONLY | _O_SEQUENTIAL,
				_S_IREAD | _S_IWRITE
			);

			if (pExtractData->pfnExtractionStatus)
			{
				pExtractData->pfnExtractionStatus(
					pfdin->psz1,
					pExtractData->wExtractedFiles,
					(WORD)((hFile != -1) ? EXTRACTION_ACTION_STARTING : EXTRACTION_ACTION_SKIPPING)
				);
			}

			return((hFile != -1) ? hFile : 0);
		}

		case fdintCLOSE_FILE_INFO:
		{
			FILETIME filetime;
			CHAR szDest[MAX_PATH];

			strcpycatA(szDest, pExtractData->szOutputPath, pfdin->psz1);

			fdiclose(pfdin->hf);

			// Set file time
			DosTimeToFileTime(pfdin->date, pfdin->time, &filetime);
			SetFileTimeByNameA(szDest, &filetime);

			// Set file attributes; we are only interested in the "standard" bits
			SetFileAttributesA(szDest, pfdin->attribs & FILE_ATTRIBUTE_STANDARD);

			++(pExtractData->wExtractedFiles);

			if (pExtractData->pfnExtractionStatus)
			{
				pExtractData->pfnExtractionStatus(
					pfdin->psz1,
					pExtractData->wExtractedFiles,
					EXTRACTION_ACTION_FINISHED
				);
			}

			return(TRUE);
		}

		case fdintNEXT_CABINET:
			return((pfdin->fdie == FDIERROR_NONE) ? 0 : -1);
	}

	return(0);
}

/**
 * GetFileTimeByName()
 * SetFileTimeByName()
 * Wraps away all the obnoxious error-checking
 **/

BOOL GetFileTimeByNameA( LPCSTR lpszFileName, LPFILETIME lpFileTime )
{
	HANDLE hFile = CreateFileA(
		lpszFileName,
		0,
		FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN,
		NULL
	);

	if (hFile == INVALID_HANDLE_VALUE)
	{
		return(FALSE);
	}
	else if (GetFileTime(hFile, NULL, NULL, lpFileTime) == FALSE)
	{
		CloseHandle(hFile);
		return(FALSE);
	}

	CloseHandle(hFile);
	return(TRUE);
}

BOOL SetFileTimeByNameA( LPCSTR lpszFileName, LPFILETIME lpFileTime )
{
	HANDLE hFile = CreateFileA(
		lpszFileName,
		GENERIC_WRITE,
		FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN,
		NULL
	);

	if (hFile == INVALID_HANDLE_VALUE)
	{
		return(FALSE);
	}
	else if (SetFileTime(hFile, NULL, NULL, lpFileTime) == FALSE)
	{
		CloseHandle(hFile);
		return(FALSE);
	}

	CloseHandle(hFile);
	return(TRUE);
}

/**
 * CreateDirectoryTree()
 * Makes sure that the given directory exists
 **/

void CreateDirectoryTreeA( LPSTR lpszPath )
{
	if (GetFileAttributesA(lpszPath) == INVALID_FILE_ATTRIBUTES)
	{
		LPSTR lpszTail = strrchr(lpszPath, '\\');

		if (lpszTail)
		{
			*lpszTail = 0;
			CreateDirectoryTreeA(lpszPath);
			*lpszTail = '\\';
			if (*(lpszTail + 1))
				CreateDirectoryA(lpszPath, NULL);
		}
		else
		{
			if (*lpszPath && *(lpszPath + 1) != ':')
				CreateDirectoryA(lpszPath, NULL);
		}
	}
}
