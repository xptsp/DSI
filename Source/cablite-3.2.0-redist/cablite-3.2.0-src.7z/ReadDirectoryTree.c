#include "ReadDirectoryTree.h"

// Setting the initial allocation too small increases the number of
// re-allocations with large trees, while setting it too high will allocate
// extra pages unnecessarily with small trees; 15 costs just under 2 pages.
#define INITIAL_ALLOC   15

// Various file extensions expressed as little-endian uint32; generated with
// the following Perl snippet:
// map {
//   printf("#define EXT_%-11s 0x%08X\n", uc($_), unpack('V', '.' . lc($_)));
// } ('acm','ax ','com','cpl','dll','drv','exe','mui','ocx','olb','scr','sys','vxd',
//    'cfg','inf','ini','reg');
// Executables
#define EXT_ACM         0x6D63612E
#define EXT_AX          0x2078612E
#define EXT_COM         0x6D6F632E
#define EXT_CPL         0x6C70632E
#define EXT_DLL         0x6C6C642E
#define EXT_DRV         0x7672642E
#define EXT_EXE         0x6578652E
#define EXT_MUI         0x69756D2E
#define EXT_OCX         0x78636F2E
#define EXT_OLB         0x626C6F2E
#define EXT_SCR         0x7263732E
#define EXT_SYS         0x7379732E
#define EXT_VXD         0x6478762E
// Config text files
#define EXT_CFG         0x6766632E
#define EXT_INF         0x666E692E
#define EXT_INI         0x696E692E
#define EXT_REG         0x6765722E

// qsort sucks because it does not support passing a user context, but qsort_s
// is not supported by the operating system's own CRT, so if qsort_s is not
// available, we will have to provide our own
#if __STDC_WANT_SECURE_LIB__
#define rdt_qsort qsort_s
#else
#include "ReadDirectoryTree.qsort.c"
#endif

// Stuff that needs to persist in WalkDirectory; also to return data.
typedef struct
{
	WORD  wEntries;
	PSTR  pszSubPaths;
	PSTR  pszSortKeys;
	PWORD pwIndexes;
	DWORD dwMaxSize;
} WALKDATA, *PWALKDATA;

BOOL WalkDirectory( PSTR pszPath, PSTR pszSubPath, PWALKDATA pListData )
{
	HANDLE hFind;
	WIN32_FIND_DATAA finddata;

	// Define some pointers to make re-using existing buffers easier; re-using
	// the buffers will allow us to get by with fewer string operations.
	PSTR pszPathAppend = pszPath + strlen(pszPath);
	PSTR pszSubPathAppend = pszSubPath + strlen(pszSubPath);

	strcpy4chA(pszPathAppend++, '\\', '*', 0, 0);

	if ((hFind = FindFirstFileA(pszPath, &finddata)) == INVALID_HANDLE_VALUE)
		return(FALSE);

	do
	{
		if (!(finddata.dwFileAttributes & FILE_ATTRIBUTE_OFFLINE))
		{
			strcpy(pszSubPathAppend, finddata.cFileName);

			if (finddata.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			{
				// Directory: Recurse

				if (!IsSpecialDirectoryName(finddata.cFileName))
				{
					strcpy(pszPathAppend, finddata.cFileName);
					strcat(pszSubPathAppend, "\\");
					WalkDirectory(pszPath, pszSubPath, pListData);
				}
			}
			else
			{
				// File: Oh boy, this is fun!

				PSTR pszSortKey;
				PSTR pszFileExt;
				UINT32 uFileExt;

				if (pListData->dwMaxSize <= pListData->wEntries)
				{
					// We need to allocate more memory!

					size_t cbWORDArray, cbPSTRArray;

					if (pListData->dwMaxSize)
					{
						// Double the existing allocation (by doubling, we
						// keep performance at O(NlogN), while memory waste
						// will be no worse than twice optimal.
						pListData->dwMaxSize <<= 1;
						if (pListData->dwMaxSize > 0xFFFF) pListData->dwMaxSize = 0xFFFF;
					}
					else
					{
						// This is our first time allocating
						pListData->dwMaxSize = INITIAL_ALLOC;
					}

					cbWORDArray = pListData->dwMaxSize * sizeof(WORD);
					cbPSTRArray = pListData->dwMaxSize * RDT_STRLEN;
					pListData->pwIndexes = realloc(pListData->pwIndexes, cbWORDArray);
					pListData->pszSubPaths = realloc(pListData->pszSubPaths, cbPSTRArray);
					pListData->pszSortKeys = realloc(pListData->pszSortKeys, cbPSTRArray);
				}

				// Update the index array and the main data array

				pListData->pwIndexes[pListData->wEntries] = pListData->wEntries;
				strcpy(pListData->pszSubPaths + (pListData->wEntries * RDT_STRLEN), pszSubPath);

				// Update the sort key array; each entry will be in the form
				// of [key][ext][space][filename] where [key] is a 1-byte
				// value to group similar file types, [ext] is the extension
				// of the filename (may be omitted), and [filename] is the
				// rest of the file name, with the extension truncated.

				pszSortKey = pListData->pszSortKeys + (pListData->wEntries * RDT_STRLEN);
				pszFileExt = strrchr(finddata.cFileName, '.');

				if (pszFileExt)
				{
					strcpycatA(pszSortKey, pszFileExt, " ");
					*pszFileExt = 0;
				}
				else
				{
					strcpy4chA(pszSortKey, '.', ' ', 0, 0);
				}

				strcat(pszSortKey, finddata.cFileName);

				// We can take the similar-types optimization one step further
				// by grouping together similar extensions.

				uFileExt = *((PUINT32)pszSortKey) | 0x20202000;

				if ( uFileExt == EXT_ACM || uFileExt == EXT_AX  || uFileExt == EXT_COM ||
				     uFileExt == EXT_CPL || uFileExt == EXT_DLL || uFileExt == EXT_DRV ||
				     uFileExt == EXT_EXE || uFileExt == EXT_MUI || uFileExt == EXT_OCX ||
				     uFileExt == EXT_OLB || uFileExt == EXT_SCR || uFileExt == EXT_SYS ||
				     uFileExt == EXT_VXD )
				{
					// This will ensure that all executable file extensions
					// are grouped together, for optimal compression.
					*pszSortKey = '0';
				}
				else if (uFileExt == EXT_CFG || uFileExt == EXT_INF ||
				         uFileExt == EXT_INI || uFileExt == EXT_REG )
				{
					// This will ensure that all configuration-style files
					// are grouped together, for optimal compression.
					*pszSortKey = '1';
				}
				else
				{
					*pszSortKey = '9';
				}

				++(pListData->wEntries);
			}
		}

	} while (FindNextFileA(hFind, &finddata) && ~(pListData->wEntries));

	return(FindClose(hFind));
}

int CompareSortKeys( PSTR psz, const WORD *a, const WORD *b )
{
	return(_stricmp(psz + (*a * RDT_STRLEN), psz + (*b * RDT_STRLEN)));
}

void ReadDirectoryTree( PCSTR pszPath, WORD *pwEntries, PWORD *ppwIndexes, PSTR *ppszSubPaths )
{
	CHAR szPath[MAX_PATH];
	CHAR szSubPath[MAX_PATH];
	WALKDATA walkdata;

	strcpy(szPath, pszPath);
	szSubPath[0] = 0;
	memset(&walkdata, 0, sizeof(walkdata));

	WalkDirectory(szPath, szSubPath, &walkdata);

	if (walkdata.wEntries)
	{
		rdt_qsort(walkdata.pwIndexes, walkdata.wEntries, sizeof(WORD),
		          CompareSortKeys, walkdata.pszSortKeys);
		free(walkdata.pszSortKeys);
	}

	*pwEntries = walkdata.wEntries;
	*ppwIndexes = walkdata.pwIndexes;
	*ppszSubPaths = walkdata.pszSubPaths;
}
