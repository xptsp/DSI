/**
 * String Intrinsics Library
 * Last modified: 2008/10/24
 *
 * This library provides two things: First, it provides intrinsic string/memory
 * functions to cover areas where there are no compiler intrinsics, in order to
 * reduce external dependencies (this may or may not improve footprint/speed),
 * and, second, it provides custom functions designed to optimize certain tasks.
 **/

#ifndef __STRINGINTRINSICS_H__
#define __STRINGINTRINSICS_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <string.h>
#include <windef.h>

#if _MSC_VER >= 1400
#pragma warning(disable: 4996) // warning about using "insecure" functions
#endif

#if _MSC_VER >= 1500 && _MSC_VER < 1600
#pragma warning(disable: 4985) // appears to be a bug in VC9
#endif

#pragma warning(push)
#pragma warning(disable: 4035) // returns for inline asm functions


// BEGIN: strcat ---------------------------------------------------------------
// byte: compiler intrinsic
// word: compiler intrinsic for VC8+, inline asm for VC7- on x86
#pragma intrinsic(strcat)
#define lstrcatA strcat

#if _MSC_VER >= 1400
#pragma intrinsic(wcscat)
#define lstrcatW wcscat
#elif defined(_M_IX86)

__inline wchar_t * intrin_strcat_w( wchar_t *dest, const wchar_t *src )
{
	__asm
	{
		xor         eax,eax
		mov         esi,src
		mov         edi,esi
		or          ecx,-1
		repnz scasw
		not         ecx
		mov         edi,dest
		push        ecx
		or          ecx,-1
		repnz scasw
		pop         ecx
		sub         edi,2
		rep movsw
	}

	return(dest);
}

#define wcscat intrin_strcat_w
#define lstrcatW intrin_strcat_w
#endif
// END: strcat -----------------------------------------------------------------


// BEGIN: strcmp ---------------------------------------------------------------
// byte: compiler intrinsic
// word: compiler intrinsic for VC8+ (also see streq)
#pragma intrinsic(strcmp)
#define lstrcmpA strcmp

#if _MSC_VER >= 1400
#pragma intrinsic(wcscmp)
#define lstrcmpW wcscmp
#endif
// END: strcmp -----------------------------------------------------------------


// BEGIN: strcpy ---------------------------------------------------------------
// byte: compiler intrinsic
// word: compiler intrinsic for VC8+, inline asm for VC7- on x86
#pragma intrinsic(strcpy)
#define lstrcpyA strcpy

#if _MSC_VER >= 1400
#pragma intrinsic(wcscpy)
#define lstrcpyW wcscpy
#elif defined(_M_IX86)

__inline wchar_t * intrin_strcpy_w( wchar_t *dest, const wchar_t *src )
{
	__asm
	{
		xor         eax,eax
		mov         esi,src
		mov         edi,esi
		or          ecx,-1
		repnz scasw
		not         ecx
		mov         edi,dest
		rep movsw
	}

	return(dest);
}

#define wcscpy intrin_strcpy_w
#define lstrcpyW intrin_strcpy_w
#endif
// END: strcpy -----------------------------------------------------------------


// BEGIN: strlen ---------------------------------------------------------------
// byte: compiler intrinsic
// word: compiler intrinsic for VC8+, inline asm for VC7- on x86
#pragma intrinsic(strlen)
#define lstrlenA strlen

#if _MSC_VER >= 1400
#pragma intrinsic(wcslen)
#define lstrlenW wcslen
#elif defined(_M_IX86)

__inline size_t intrin_strlen_w( const wchar_t *string )
{
	__asm
	{
		xor         eax,eax
		mov         edi,string
		or          ecx,-1
		repnz scasw
		not         ecx
		dec         ecx
		xchg        eax,ecx
	}
}

#define wcslen intrin_strlen_w
#define lstrlenW intrin_strlen_w
#endif
// END: strlen -----------------------------------------------------------------


// BEGIN: memcmp, memcpy, memset -----------------------------------------------
// compiler intrinsic for VC7-, forced compiler intrinsic for VC8+
#pragma intrinsic(memcmp, memcpy, memset)

#if _MSC_VER >= 1400 && (defined(_M_IX86) || defined(_M_AMD64) || defined(_M_X64))
#ifndef __INTRIN_H_
void __movsb( unsigned char *, unsigned char const *, size_t );
void __stosb( unsigned char *, unsigned char, size_t );
#endif

#pragma intrinsic(__movsb, __stosb)

__inline void * intrin_memcpy( void *dest, const void *src, size_t count )
{
	__movsb((unsigned char *)dest, (unsigned char const *)src, count);
	return(dest);
}

__inline void * intrin_memset( void *dest, int c, size_t count )
{
	__stosb((unsigned char *)dest, (unsigned char)c, count);
	return(dest);
}

#define memcpy intrin_memcpy
#define memset intrin_memset
#endif
// END: memcmp, memcpy, memset -------------------------------------------------


// BEGIN: streq ----------------------------------------------------------------
// This is a custom function: zero if strings are unequal, nonzero otherwise;
// this is simpler to implement than strcmp
// byte: inline asm on x86, strcmp == 0 otherwise
// word: inline asm on x86, strcmp == 0 otherwise
#if defined(_M_IX86)

__inline int intrin_streq_b( const char *string1, const char *string2 )
{
	__asm
	{
		xor         eax,eax
		mov         esi,string2
		mov         edi,esi
		or          ecx,-1
		repnz scasb
		not         ecx
		mov         edi,string1
		repe cmpsb
		sete        al
	}
}

__inline int intrin_streq_w( const wchar_t *string1, const wchar_t *string2 )
{
	__asm
	{
		xor         eax,eax
		mov         esi,string2
		mov         edi,esi
		or          ecx,-1
		repnz scasw
		not         ecx
		mov         edi,string1
		repe cmpsw
		sete        al
	}
}

#define streqA intrin_streq_b
#define streqW intrin_streq_w
#else
#define streqA(a, b) (lstrcmpA(a, b) == 0)
#define streqW(a, b) (lstrcmpW(a, b) == 0)
#endif

#ifdef UNICODE
#define streq streqW
#else
#define streq streqA
#endif
// END: streq ------------------------------------------------------------------


// BEGIN: strcpycat ------------------------------------------------------------
// This is a custom function: same as strcpy(dest, src1); strcat(dest, src2);
// byte: inline asm on x86, optimized inline function otherwise
// word: inline asm on x86, optimized inline function otherwise
#if defined(_M_IX86)

__inline char * intrin_strcpycat_b( char *dest, const char *src1, const char *src2 )
{
	__asm
	{
		xor         eax,eax

		mov         esi,src1
		mov         edi,esi
		or          ecx,-1
		repnz scasb
		not         ecx
		dec         ecx
		mov         edi,dest
		rep movsb
		push        edi

		mov         esi,src2
		mov         edi,esi
		or          ecx,-1
		repnz scasb
		not         ecx
		pop         edi
		rep movsb
	}

	return(dest);
}

__inline wchar_t * intrin_strcpycat_w( wchar_t *dest, const wchar_t *src1, const wchar_t *src2 )
{
	__asm
	{
		xor         eax,eax

		mov         esi,src1
		mov         edi,esi
		or          ecx,-1
		repnz scasw
		not         ecx
		dec         ecx
		mov         edi,dest
		rep movsw
		push        edi

		mov         esi,src2
		mov         edi,esi
		or          ecx,-1
		repnz scasw
		not         ecx
		pop         edi
		rep movsw
	}

	return(dest);
}

#else

__inline char * intrin_strcpycat_b( char *dest, const char *src1, const char *src2 )
{
	size_t cb = strlen(src1);
	memcpy(dest, src1, cb);
	dest += cb;
	strcpy(dest, src2);
	return(dest);
}

__inline wchar_t * intrin_strcpycat_w( wchar_t *dest, const wchar_t *src1, const wchar_t *src2 )
{
	size_t cw = wcslen(src1);
	memcpy(dest, src1, cw << 1);
	dest += cw;
	wcscpy(dest, src2);
	return(dest);
}

#endif

#define strcpycatA intrin_strcpycat_b
#define strcpycatW intrin_strcpycat_w
#ifdef UNICODE
#define strcpycat strcpycatW
#else
#define strcpycat strcpycatA
#endif
// END: strcpycat --------------------------------------------------------------


// BEGIN: chaincat -------------------------------------------------------------
// This is a custom function: same as strcat, but instead of uselessly
// returning the start of the string, it returns the end of the string instead
// byte: inline asm on x86, optimized inline function otherwise
// word: inline asm on x86, optimized inline function otherwise
#if defined(_M_IX86)

__inline char * intrin_chaincat_b( char *dest, const char *src )
{
	__asm
	{
		xor         eax,eax
		mov         esi,src
		mov         edi,esi
		or          ecx,-1
		repnz scasb
		not         ecx
		mov         edi,dest
		push        ecx
		or          ecx,-1
		repnz scasb
		pop         ecx
		dec         edi
		rep movsb
		dec         edi
		xchg        eax,edi
	}
}

__inline wchar_t * intrin_chaincat_w( wchar_t *dest, const wchar_t *src )
{
	__asm
	{
		xor         eax,eax
		mov         esi,src
		mov         edi,esi
		or          ecx,-1
		repnz scasw
		not         ecx
		mov         edi,dest
		push        ecx
		or          ecx,-1
		repnz scasw
		pop         ecx
		sub         edi,2
		rep movsw
		sub         edi,2
		xchg        eax,edi
	}
}

#else

__inline char * intrin_chaincat_b( char *dest, const char *src )
{
	strcat(dest, src);
	return(dest + strlen(dest));
}

__inline wchar_t * intrin_chaincat_w( wchar_t *dest, const wchar_t *src )
{
	wcscat(dest, src);
	return(dest + wcslen(dest));
}

#endif

#define chaincatA intrin_chaincat_b
#define chaincatW intrin_chaincat_w
#ifdef UNICODE
#define chaincat chaincatW
#else
#define chaincat chaincatA
#endif
// END: chaincat ---------------------------------------------------------------


// BEGIN: chaincpy -------------------------------------------------------------
// This is a custom function: same as strcpy, but instead of uselessly
// returning the start of the string, it returns the end of the string instead
// byte: inline asm on x86, optimized inline function otherwise
// word: inline asm on x86, optimized inline function otherwise
#if defined(_M_IX86)

__inline char * intrin_chaincpy_b( char *dest, const char *src )
{
	__asm
	{
		xor         eax,eax
		mov         esi,src
		mov         edi,esi
		or          ecx,-1
		repnz scasb
		not         ecx
		mov         edi,dest
		rep movsb
		dec         edi
		xchg        eax,edi
	}
}

__inline wchar_t * intrin_chaincpy_w( wchar_t *dest, const wchar_t *src )
{
	__asm
	{
		xor         eax,eax
		mov         esi,src
		mov         edi,esi
		or          ecx,-1
		repnz scasw
		not         ecx
		mov         edi,dest
		rep movsw
		sub         edi,2
		xchg        eax,edi
	}
}

#else

__inline char * intrin_chaincpy_b( char *dest, const char *src )
{
	size_t cb = strlen(src);
	memcpy(dest, src, cb + 1);
	return(dest + cb);
}

__inline wchar_t * intrin_chaincpy_w( wchar_t *dest, const wchar_t *src )
{
	size_t cw = wcslen(src);
	memcpy(dest, src, (cw + 1) << 1);
	return(dest + cw);
}

#endif

#define chaincpyA intrin_chaincpy_b
#define chaincpyW intrin_chaincpy_w
#ifdef UNICODE
#define chaincpy chaincpyW
#else
#define chaincpy chaincpyA
#endif
// END: chaincpy ---------------------------------------------------------------


// BEGIN: chaincpycat ----------------------------------------------------------
// This is a custom function: same as strcpycat, but instead of uselessly
// returning the start of the string, it returns the end of the string instead
// byte: inline asm on x86, optimized inline function otherwise
// word: inline asm on x86, optimized inline function otherwise
#if defined(_M_IX86)

__inline char * intrin_chaincpycat_b( char *dest, const char *src1, const char *src2 )
{
	__asm
	{
		xor         eax,eax

		mov         esi,src1
		mov         edi,esi
		or          ecx,-1
		repnz scasb
		not         ecx
		dec         ecx
		mov         edi,dest
		rep movsb
		push        edi

		mov         esi,src2
		mov         edi,esi
		or          ecx,-1
		repnz scasb
		not         ecx
		pop         edi
		rep movsb
		dec         edi
		xchg        eax,edi
	}
}

__inline wchar_t * intrin_chaincpycat_w( wchar_t *dest, const wchar_t *src1, const wchar_t *src2 )
{
	__asm
	{
		xor         eax,eax

		mov         esi,src1
		mov         edi,esi
		or          ecx,-1
		repnz scasw
		not         ecx
		dec         ecx
		mov         edi,dest
		rep movsw
		push        edi

		mov         esi,src2
		mov         edi,esi
		or          ecx,-1
		repnz scasw
		not         ecx
		pop         edi
		rep movsw
		sub         edi,2
		xchg        eax,edi
	}
}

#else

__inline char * intrin_chaincpycat_b( char *dest, const char *src1, const char *src2 )
{
	size_t cb = strlen(src1);
	memcpy(dest, src1, cb);
	dest += cb;
	return(chaincpyA(dest, src2));
}

__inline wchar_t * intrin_chaincpycat_w( wchar_t *dest, const wchar_t *src1, const wchar_t *src2 )
{
	size_t cw = wcslen(src1);
	memcpy(dest, src1, cw << 1);
	dest += cw;
	return(chaincpyW(dest, src2));
}

#endif

#define chaincpycatA intrin_chaincpycat_b
#define chaincpycatW intrin_chaincpycat_w
#ifdef UNICODE
#define chaincpycat chaincpycatW
#else
#define chaincpycat chaincpycatA
#endif
// END: chaincpycat ------------------------------------------------------------


// BEGIN: strcpyNch ------------------------------------------------------------
// This is a custom function: copy const strings of 2 or 4 characters in length
// byte: 2 (WORD) or 4 (DWORD) character versions available
// word: 2 (DWORD) character version available
__inline void intrin_strcpyw( void *dest,  WORD src ) { *( (PWORD)dest) = src; }
__inline void intrin_strcpyd( void *dest, DWORD src ) { *((PDWORD)dest) = src; }

#define CAST2BYTE(a)                ((BYTE)((DWORD_PTR)(a) & 0xFF))
#define CAST2WORD(a)                ((WORD)((DWORD_PTR)(a) & 0xFFFF))
#define CHARS2WORD(a, b)            ((WORD)(CAST2BYTE(a) | ((WORD)CAST2BYTE(b)) << 8))
#define WCHARS2DWORD(a, b)          ((DWORD)(CAST2WORD(a) | ((DWORD)CAST2WORD(b)) << 16))
#define CHARS2DWORD(a, b, c, d)     WCHARS2DWORD(CHARS2WORD(a, b), CHARS2WORD(c, d))
#define strcpy2chA(s, a, b)         intrin_strcpyw(s, CHARS2WORD(a, b))
#define strcpy2chW(s, a, b)         intrin_strcpyd(s, WCHARS2DWORD(a, b))
#define strcpy4chA(s, a, b, c, d)   intrin_strcpyd(s, CHARS2DWORD(a, b, c, d))

#ifdef UNICODE
#define strcpy2ch strcpy2chW
#else
#define strcpy2ch strcpy2chA
#endif
// END: strcpyNch --------------------------------------------------------------


#pragma warning(pop)

#ifdef __cplusplus
}
#endif

#endif
