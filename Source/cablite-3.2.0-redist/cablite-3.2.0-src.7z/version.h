// Full name; this will appear in the version info
#if defined(_M_IX86)
#define CABLITE_NAME_STR "Light-weight Cabinet Library (x86-32)"
#elif defined(_M_AMD64) || defined(_M_X64)
#define CABLITE_NAME_STR "Light-weight Cabinet Library (x86-64)"
#else
#define CABLITE_NAME_STR "Light-weight Cabinet Library"
#endif

// Full version: MUST be in the form of major,minor,revision,build
#define CABLITE_VERSION_FULL 3,2,0,0

// String version: May be any suitable string
#define CABLITE_VERSION_STR "3.2.0 (2008/11/10)"

#ifdef _USRDLL
// PE version: MUST be in the form of major.minor
#pragma comment(linker, "/version:3.2")
#endif
